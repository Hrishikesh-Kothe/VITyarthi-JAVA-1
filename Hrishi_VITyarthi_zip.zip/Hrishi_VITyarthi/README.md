# Java Project - Vityarthi

## Student Details
- **Name:** Hrishikesh Kothe
- **Reg No:** 24BCE10002

---

## Project Overview
This repository contains a Java-based for VITyarthi 

---

## How to Run
1. Clone or download the repository.
2. Open the project in an IDE (VS Code, IntelliJ, or Eclipse).
3. Compile the Java files:
   ```bash
   javac *.java
   ```
4. Run the main class:
   ```bash
   java Main
   ```
